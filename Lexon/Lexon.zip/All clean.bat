@echo off
REM Double-click this to build a clean Lexon.zip in this same folder,
REM using package-for-review.ps1. Keep both files together, ideally
REM saved once at the root of your Lexon working copy.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0package-for-review.ps1" -SourcePath "%~dp0" -OutputZip "%~dp0Lexon.zip"
pause
